import pymsteams
import os 
import logging 

logger = logging.getLogger()
logger.setLevel(logging.INFO)

hook_url = os.getenv('HOOK_URL', None)
mteam_custom_action_arn = os.getenv('MTEAM_CUSTOM_ACITON_ARN', None)

def send_message_to_msteam(title,findings):
    if hook_url:
    
        myTeamsMessage = pymsteams.connectorcard(hook_url)
        for finding in findings:
            account = finding["AwsAccountId"]
            region = finding["Region"]
            finding_id = finding["Id"]
            finding_title = finding["Title"]
            description = finding["Description"]
            severity = finding["Severity"]["Label"]
            event_time = finding["CreatedAt"]
            resource = str(finding["Resources"])
            
            myTeamsMessage.summary(title)
            myTeamsMessage.title("Alert from AWS Security Hub")
            
            message = pymsteams.cardsection() 
            message.addFact("Account", account)
            message.addFact("Region", region)
            message.addFact("EventTime", event_time)
            message.addFact("FindingId", finding_id)
            message.addFact("FindingTitle", finding_title)
            message.addFact("Description", description)
            message.addFact("Severity", severity)
            message.addFact("Resource", resource)
            
            myTeamsMessage.addSection(message)
            myTeamsMessage.send()
            
        myTeamsMessage = None

def lambda_handler(event,_):
    try:
        if mteam_custom_action_arn in event["resources"]:
            title = event["detail"]["actionName"]
            findings = event["detail"]["findings"]
            send_message_to_msteam(title, findings)
    except Exception as e:
        logging.error(e)